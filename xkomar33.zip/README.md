Implementace překladače imperativního jazyka IFJ21
Rozšíření: FUNEXP

autoři:
Jakub Komárek (xkomar33) 
Křivánek Jakub (xkriva30) 
Matušík Adrián (xmatus35) 
Tverdokhlib Vladyslav V. (xtverd01) 
