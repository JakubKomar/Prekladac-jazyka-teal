Překaladač jazyku IFJ21 do jazyku IFJCODE21

